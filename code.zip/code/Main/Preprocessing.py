import numpy as np
import read
import cv2


def process(path):

    Img=read.image(path)

    for i in range(len(Img)):
        print("i :",i)
        img = cv2.imread(Img[i], cv2.IMREAD_GRAYSCALE).astype(float)
        rows, cols = img.shape[:2]
        ksize = 5
        padsize = int((ksize - 1) / 2)
        pad_img = cv2.copyMakeBorder(img, *[padsize] * 4, cv2.BORDER_DEFAULT)
        geomean1 = np.zeros_like(img)
        for r in range(rows):
            for c in range(cols):
                geomean1[r, c] = np.prod(pad_img[r:r + ksize, c:c + ksize]) ** (1 / (ksize ** 2))
        geomean1 = np.uint8(geomean1)

        cv2.imwrite("Processed//Preprocessing_Img/"+str(i)+".jpg",geomean1)


def images(path):

    #process(path)

    pre_img_path="Processed//Preprocessing_Img/*"
    imgg=read.image(pre_img_path)
    return imgg