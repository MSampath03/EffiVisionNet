import read
from Fea_Extraction import FLBP
from Fea_Extraction import SLIF
import numpy as np
import glob
import pandas as pd

def Ext_Fea(path):

    Img_path=read.image(path)

    FLBP.FLBP_fea(Img_path)
    Stat_fea=SLIF.slif_f(Img_path)
    np.savetxt("Processed/Ext_Features/Stat_Feature.csv", Stat_fea, delimiter=',', fmt='%s')




def Features(path):

    #Ext_Fea(path)

    pa = 'Processed/Ext_Features/*'

    # setting the path for joining multiple files
    data = []
    # list of merged files returned
    files = glob.glob(pa)

    for file in files:
        df_list = pd.read_csv(file, header=None)
        data.append(df_list)
    # joining files with concat and read_csv

    feature = pd.concat(data, axis=1)
    feature = np.array(feature)

    Label=pd.read_csv("Processed/Label.csv",header=None)
    Label=np.array(Label)


    return feature,Label