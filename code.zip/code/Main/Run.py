import Preprocessing
import Fea_Ext
import Proposed_EffiVisionNet.EfficientNet
import Proposed_EffiVisionNet.Fusion
import Proposed_EffiVisionNet.Regression
import Proposed_EffiVisionNet.VIT_Transformer
import DHL.DHL
import deep_sparse_graph_ttention_network.Graph_AN
import SM_Net.NN
import LSTM.LSTM


def callmain(tr):
    PRE,REC,F1_S,ACC=[],[],[],[]

    Data_path='Dataset/VRD/*'

    Pre_Img=Preprocessing.images(Data_path)  # Preprocessing by using Mean filter

    DO='Processed/Detected_object/*'  # Detected object is stored along this path

    #Feature Extraction(entropy based FLBP, SLIF,statistical feature)

    Fea,label=Fea_Ext.Features(DO)

    #relationship graph prediction
    l1,weight=Proposed_EffiVisionNet.EfficientNet.classify(DO, label, tr)
    F=Proposed_EffiVisionNet.Fusion.callmain(Fea, l1, weight)
    l2=Proposed_EffiVisionNet.Regression.classify(F, tr, label)
    Proposed_EffiVisionNet.VIT_Transformer.Classify(Pre_Img, l2, label, tr, PRE, REC, F1_S,ACC)
    
    return PRE,REC,F1_S,ACC


