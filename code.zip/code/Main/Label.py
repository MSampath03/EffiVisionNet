import read
import numpy as np

def label():
    DO='Processed/Detected_object/*'

    Img=read.image(DO)
    Label=[]
    for i in range(len(Img)):

        A=Img[i].split("_")
        A1=A[2].split('.')
        A1=int(A1[0])
        Label.append(A1)
    #print(">>>>>", Label)
    np.savetxt("Processed/Label.csv",Label,delimiter=',',fmt='%s')


