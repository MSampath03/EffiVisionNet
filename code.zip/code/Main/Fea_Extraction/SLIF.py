import cv2 as cv     #pip install opencv-contrib-python
import numpy as np
from Main.Fea_Extraction import Statistical_Feature
def slif_f(img):
    MEAN,VAR,STD_DEV,KUR,SK=[],[],[],[],[]
    SLIFT_F=[]
    for i in range(len(img)):
        print("SLIF :",i)
        image = cv.imread(img[i])

        # convert to grayscale image
        gray_scale = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

        # initialize SLIF object
        slif = cv.SIFT.create()

        # detect keypoints
        keypoints, _ = slif.detectAndCompute(image, None)

        # draw keypoints
        slif_image = cv.drawKeypoints(gray_scale, keypoints, None)
        histograms, bins = np.histogram(slif_image, bins=[0, 10, 20, 30, 40, 50, 60, 70, 80, 90,
                                                             100])  # calculating feature vector for the image
        histograms = histograms.flatten()
        SLIFT_F.append(histograms)
        np.savetxt("Processed/Ext_Features/SLIFT-Feature.csv", SLIFT_F, delimiter=',', fmt='%s')
        Mean,Variance,std_Deviation,kur,sk=Statistical_Feature.Stat_Fea(slif_image)
        MEAN.append(Mean)
        VAR.append(Variance)
        STD_DEV.append(std_Deviation)
        KUR.append(kur)
        SK.append(sk)
    Stat_Fea = np.column_stack((MEAN, VAR, STD_DEV, KUR, SK))

    return Stat_Fea


