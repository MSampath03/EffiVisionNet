import cv2
import numpy as np
import scipy


def Stat_Fea(img):


    Mean= img.mean()

    Variance=np.var(img)

    std_Deviation=np.std(img)

    kur = scipy.stats.kurtosis(img)

    sk = scipy.stats.skew(img)

    return Mean,Variance,std_Deviation,kur[0],sk[0]



