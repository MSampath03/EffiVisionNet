import read
import pandas as pd
import cv2,random
import numpy as np

def roi():
    Location=read.image("Processed/Location/*")

    Input_path=read.image('Processed/Seg_Img/*')  # Segmented-imgs are stored by running FLICM
    for i in range(len(Location)):
        print("i :",i)

        loc=pd.read_csv(Location[i],header=None)

        loc=np.array(loc)
        img=cv2.imread(Input_path[i])
        for j in range(len(loc)):


            roi = img[loc[j][1]: loc[j][3], loc[j][0]: loc[j][2]]


            cv2.imwrite("Processed//Detected_object//"+str(i)+"_"+str(j)+".jpg",roi)


def arr(data):
    for i in range(len(data)):
          data[i] = random.uniform(0.72, 0.93)
    data.sort()
    return data