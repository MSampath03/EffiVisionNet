import numpy as np

def callmain(Fea,l1,weight):
    FLBP_F=Fea[:,0:10]
    SLIF_F=Fea[:,10:20]
    SF=Fea[:,20:-1]

    h=10
    data=[]
    for i in range(len(SF)):
        temp=[]
        for j in range(len(SF[i])):
            y=FLBP_F[i][j]*weight
            y1=SLIF_F[i][j]*weight
            y2=SF[i][j]*weight
            #-----------Applying fractional concept------------

            l2=h*y+(h/2)*y1+(1/6)*(1-h)*y2+(1/24)*h*(1-h)*(2-h)*l1[0][0]
            temp.append(l2)

        data.append(temp)

    return data
