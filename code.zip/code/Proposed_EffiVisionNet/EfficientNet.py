from tensorflow.keras.applications import EfficientNetB0
import numpy as np
import cv2
from Main import read

def input_preprocess(image, label,tr):
    label=label[0:int(tr*100)]
    IMG=[]
    for i in range(len(image)):
        imgg=cv2.imread(image[i])

        IMG.append(imgg)

    return IMG, label


def classify(path,Label,tr):
    Seg_Img=read.image(path)
    Imgs=Seg_Img[0:int(tr*100)]
    Img=input_preprocess(Imgs,Label,tr)
    model = EfficientNetB0(weights='imagenet')
    weight=model.get_weights()
    Img=np.resize(Img[0][0],(len(Img),224,224,3))
    Pred=model.predict(np.array(Img))

    return Pred,np.mean(weight[0])
